﻿import React, { useEffect, useState } from "react";
import { getNotes, deleteNote } from "../../../../services/notes/noteService";
import { useNavigate } from "react-router-dom";

export default function NoteList() {
  const [notes, setNotes] = useState([]);
  const [loading, setLoading] = useState(true);
  const navigate = useNavigate();

  useEffect(() => {
    loadNotes();
  }, []);

  const loadNotes = async () => {
    setLoading(true);
    try {
      const res = await getNotes();
      setNotes(res.data.data);
    } catch (error) {
      console.error(error);
    } finally {
      setLoading(false);
    }
  };

  const handleDelete = async (id) => {
    if (window.confirm("Supprimer cette note ?")) {
      try {
        await deleteNote(id);
        loadNotes();
      } catch (error) {
        alert("Erreur lors de la suppression");
      }
    }
  };

  return (
    <div className="p-4">
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-2xl font-bold">Liste des notes</h2>
        <button 
          onClick={() => navigate("/notes/create")}
          className="bg-green-600 text-white px-4 py-2 rounded flex items-center gap-2"
        >
          <i className="bi bi-plus-circle"></i> Ajouter une note
        </button>
      </div>

      {loading ? (
        <p>Chargement...</p>
      ) : (
        <div className="overflow-x-auto shadow-md rounded-lg">
          <table className="w-full text-left border-collapse bg-white">
            <thead className="bg-gray-100 border-b">
              <tr>
                <th className="p-3">Élève</th>
                <th className="p-3">Matière</th>
                <th className="p-3">Classe</th>
                <th className="p-3">Type</th>
                <th className="p-3">Période</th>
                <th className="p-3">Note</th>
                <th className="p-3 text-center">Actions</th>
              </tr>
            </thead>

            <tbody>
              {notes.length === 0 ? (
                <tr>
                  <td colSpan="7" className="p-4 text-center text-gray-500">Aucune note trouvée</td>
                </tr>
              ) : (
                notes.map((n) => (
                  <tr key={n.id} className="border-b hover:bg-gray-50">
                    <td className="p-3">{n.eleve?.prenom} {n.eleve?.nom}</td>
                    <td className="p-3 font-medium">{n.matiere?.nom_matiere}</td>
                    <td className="p-3">{n.classe?.nom_classe}</td>
                    <td className="p-3 text-sm text-gray-600">{n.type_evaluation}</td>
                    <td className="p-3 text-sm text-gray-600">{n.periode}</td>
                    <td className="p-3">
                      <span className="font-bold">
                        {n.valeur} / 20
                      </span>
                    </td>

                    <td className="p-3 text-center space-x-2">
                      <button 
                        onClick={() => navigate(`/notes/edit/${n.id}`)}
                        className="text-blue-600 hover:text-blue-800"
                        title="Modifier"
                      >

                        <i className="bi bi-pencil-square text-lg"></i>
                      </button>

                      <button 
                        onClick={() => handleDelete(n.id)}
                        className="text-red-600 hover:text-red-800"
                        title="Supprimer"
                      >
                        <i className="bi bi-trash text-lg"></i>
                      </button>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
