import React, { useEffect, useState } from "react";
import { createNote } from "../../../../services/notes/noteService";
import axios from "../../../../api/axios";
import { useNavigate } from "react-router-dom";

export default function NoteCreate() {
  const navigate = useNavigate();

  const [eleves, setEleves] = useState([]);
  const [matieres, setMatieres] = useState([]);
  const [classes, setClasses] = useState([]);
  const [loading, setLoading] = useState(false);

  const [form, setForm] = useState({
    id_eleve: "",
    id_matiere: "",
    id_classe: "",
    valeur: "",
    type_evaluation: "Devoir",
    periode: "Trimestre 1",
  });

  useEffect(() => {
    // Dans un vrai projet, on filtrerait selon l'enseignant connecté
    axios.get("/users?role=ELEVE").then(res => setEleves(res.data.data || res.data));
    axios.get("/matieres").then(res => setMatieres(res.data.data || res.data));
    axios.get("/classes").then(res => setClasses(res.data.data || res.data));
  }, []);

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);

    try {
      await createNote(form);
      alert("Note ajoutée avec succès !");
      navigate("/notes");
    } catch (error) {
      console.error(error.response?.data || error);
      alert("Erreur lors de l'ajout : " + (error.response?.data?.message || "Erreur inconnue"));
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="p-4">
      <h2 className="text-2xl font-bold mb-6">Saisir une note</h2>

      <form onSubmit={handleSubmit} className="bg-white p-6 rounded-lg shadow-md space-y-4 max-w-2xl">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          
          {/* CLASSE */}
          <div>
            <label className="block text-sm font-medium mb-1">Classe</label>
            <select name="id_classe" onChange={handleChange} value={form.id_classe} className="w-full p-2 border rounded" required>
              <option value="">-- Sélectionner une classe --</option>
              {classes.map(c => (
                <option key={c.id} value={c.id}>{c.nom_classe}</option>
              ))}
            </select>
          </div>

          {/* MATIERE */}
          <div>
            <label className="block text-sm font-medium mb-1">Matière</label>
            <select name="id_matiere" onChange={handleChange} value={form.id_matiere} className="w-full p-2 border rounded" required>
              <option value="">-- Sélectionner une matière --</option>
              {matieres.map(m => (
                <option key={m.id} value={m.id}>{m.nom_matiere}</option>
              ))}
            </select>
          </div>

          {/* ELEVE */}
          <div>
            <label className="block text-sm font-medium mb-1">Élève</label>
            <select name="id_eleve" onChange={handleChange} value={form.id_eleve} className="w-full p-2 border rounded" required>
              <option value="">-- Sélectionner un élève --</option>
              {eleves.map(e => (
                <option key={e.id} value={e.id}>{e.prenom} {e.nom}</option>
              ))}
            </select>
          </div>

          {/* TYPE */}
          <div>
            <label className="block text-sm font-medium mb-1">Type d'évaluation</label>
            <select name="type_evaluation" onChange={handleChange} value={form.type_evaluation} className="w-full p-2 border rounded" required>
              <option value="Devoir">Devoir</option>
              <option value="Examen">Examen</option>
              <option value="Interrogation">Interrogation</option>
            </select>
          </div>

          {/* PERIODE */}
          <div>
            <label className="block text-sm font-medium mb-1">Période</label>
            <select name="periode" onChange={handleChange} value={form.periode} className="w-full p-2 border rounded" required>
              <option value="Trimestre 1">Trimestre 1</option>
              <option value="Trimestre 2">Trimestre 2</option>
              <option value="Trimestre 3">Trimestre 3</option>
              <option value="Semestre 1">Semestre 1</option>
              <option value="Semestre 2">Semestre 2</option>
            </select>
          </div>

          {/* NOTE */}
          <div>
            <label className="block text-sm font-medium mb-1">Note (sur 20)</label>
            <input
              type="number"
              step="0.25"
              min="0"
              max="20"
              name="valeur"
              value={form.valeur}
              placeholder="0.00"
              onChange={handleChange}
              className="w-full p-2 border rounded"
              required
            />
          </div>
        </div>

        <div className="pt-4 flex gap-3">
          <button 
            type="submit" 
            disabled={loading}
            className="bg-blue-600 text-white px-6 py-2 rounded font-medium disabled:bg-blue-300"
          >
            {loading ? "Enregistrement..." : "Enregistrer la note"}
          </button>
          <button 
            type="button" 
            onClick={() => navigate("/notes")}
            className="bg-gray-200 text-gray-700 px-6 py-2 rounded font-medium"
          >
            Annuler
          </button>
        </div>
      </form>
    </div>
  );
}
