import axios from "../../api/axios";

const NOTE_API = "/notes";

// 📌 Liste avec filtres
export const getNotes = (filters = {}) => {
  return axios.get(NOTE_API, { params: filters });
};

// 📌 Ajouter note
export const createNote = (data) => {
  return axios.post(NOTE_API, data);
};

// 📌 Modifier note
export const updateNote = (id, data) => {
  return axios.put(`${NOTE_API}/${id}`, data);
};

// 📌 Récupérer une note par ID
export const getNoteById = (id) => {
  return axios.get(`${NOTE_API}/${id}`);
};

// 📌 Supprimer note (optionnel)
export const deleteNote = (id) => {
  return axios.delete(`${NOTE_API}/${id}`);
};

// 📌 Résultats par classe
export const getResultatsClasse = (classeId) => {
  return axios.get(`/notes/resultats/classe/${classeId}`);
};

// 📌 Résultats par élève
export const getResultatsEleve = (eleveId) => {
  return axios.get(`/notes/resultats/eleve/${eleveId}`);
};